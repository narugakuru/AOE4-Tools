import time
import keyboard
import argparse
from datetime import datetime


def press_keys():
    t = 0.03
    # 按下大写H键
    keyboard.press("H")
    keyboard.release("H")
    time.sleep(t)
    # 按下N次Q键
    for _ in range(n):
        keyboard.press("q")
        keyboard.release("q")
        time.sleep(t)
    time.sleep(t)
    # 按下Esc键
    keyboard.press("esc")
    keyboard.release("esc")


if __name__ == "__main__":
    # 解析命令行参数
    parser = argparse.ArgumentParser(description="Keyboard automation script")
    parser.add_argument(
        "-n", type=int, default=1, help="Number of times to press Q key"
    )
    args = parser.parse_args()
    n = args.n * 2
    print("===循环开始===")
    while True:
        # 获取当前时间
        now = datetime.now()
        print(f"===Current time: {now.strftime('%H:%M:%S')}，执行{n}次=== ")
        press_keys()
        time.sleep(39)
